import LinearRegression
import train_regression1
import numpy as np

obj = train_regression1
X_test = obj.X_test
y_test = obj.y_test
model1 = obj.model1
X_test = np.array(X_test)
a1 = np.ones((len(X_test), 1), float)
X_test = np.concatenate((a1, X_test), axis=1)
pred1 = model1.predict(X_test)

obj1 = LinearRegression.LinearRegression()
error1 = obj1.score(pred1, y_test)
print(error1)