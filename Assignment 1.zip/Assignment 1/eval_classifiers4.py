import numpy as np
import LinearDiscrimanantAnalysis
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from mlxtend.plotting import plot_decision_regions


obj = LinearDiscrimanantAnalysis
iris = load_iris()
X = iris['data']
X = np.array(X)
y = iris['target']
y = np.array(y)
X = X[:, [2, 3]]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1)
model = obj.LinearDiscriminantAnalysis()
w, b = model.fit(X_train, y_train)
pre = model.predict(X_test)
print(pre)
print(y_test)

plot_decision_regions(X = X_test, y=y_test, clf = model)

plt.xlabel('Feature 0')
plt.ylabel('Feature 1')
plt.title('Linear Discriminat Analysis')

plt.show()

count = 0
for i in range(len(y_test)):
    if y_test[i] == pre[i]:
        count += 1
    else:
        count += 0

print((count/len(y_test))*100)
