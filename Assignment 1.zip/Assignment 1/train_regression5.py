import LinearRegressionRegularization
import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

# Model1 Sepal Length, Sepal Width -->> Petal length self.weights = [[0.11540477], [ 1.58165409], [-1.70781493]]

obj = LinearRegressionRegularization
iris = load_iris()
X = iris['data']
y = iris['target']
X_1 = X[:, [0, 1]]
y1 = X[:, 2]
X_train, X_test, y_train, y_test = train_test_split(X_1, y1, test_size=0.1)
model1 = obj.LinearRegressionRegularization()
w1, loss_values = model1.fit(X_1, y1)
np.savetxt('weights5', w1, delimiter=',')

step_numbers = []
for i in range(len(loss_values)):
    step_numbers.append(i+1)

plt.plot(step_numbers, loss_values)
plt.xlabel('Step Number')
plt.ylabel('Loss')
plt.title('Loss vs. Step Number')
plt.grid(True)
plt.show()

# Code to retrive saved weights
# Weights = np.loadtxt("weights5.csv", delimiter=",")
