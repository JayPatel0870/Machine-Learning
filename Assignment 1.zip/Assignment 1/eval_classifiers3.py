from sklearn.datasets import load_iris
import LogisticRegression
import numpy as np
from sklearn.model_selection import train_test_split

obj = LogisticRegression
iris = load_iris()
X = iris['data']
y = iris['target']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1)
model = obj.LogisticRegression()
X_train = np.concatenate((np.ones((X_train.shape[0], 1)), X_train), axis=-1)
w = model.fit(X_train, y_train)
z = model.predict(X_test)
print(y_test)
print(z)

count = 0
for i in range(len(y_test)):
    if y_test[i] == z[i]:
        count += 1
    else:
        count += 0

print((count/len(y_test))*100)
