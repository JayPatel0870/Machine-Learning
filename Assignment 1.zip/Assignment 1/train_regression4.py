import LinearRegression
import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

#  Model 4 Sepal Width -->> Sepal Length self.weights = [[3.35540585], [0.90490776]]

obj = LinearRegression
iris = load_iris()
X = iris['data']
y = iris['target']
X_4 = X[:, 1]
X_4 = X_4.reshape(len(X_4), 1)
y4 = X[:, 0]
y4 = y4.reshape(len(y4), 1)
X_train, X_test, y_train, y_test = train_test_split(X_4, y4, test_size=0.1)
model4 = obj.LinearRegression()
w4, loss_values = model4.fit(X_4, y4)
np.savetxt('weights4', w4, delimiter=',')

step_numbers = []
for i in range(len(loss_values)):
    step_numbers.append(i+1)

plt.plot(step_numbers, loss_values)
plt.xlabel('Step Number')
plt.ylabel('Loss')
plt.title('Loss vs. Step Number')
plt.grid(True)
plt.show()

# Code to retrive saved weights
# Weights = np.loadtxt("weights4.csv", delimiter=",")
