import LinearRegression
import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

# Model3 Sepal Length -->> Petal Length Self.weights = [[-0.93456275], [ 0.96994427]]

obj = LinearRegression
iris = load_iris()
X = iris['data']
y = iris['target']
X_3 = X[:, 0]
X_3 = X_3.reshape(len(X_3), 1)
y3 = X[:, 2]
y3 = y3.reshape(len(y3), 1)
X_train, X_test, y_train, y_test = train_test_split(X_3, y3, test_size=0.1)
model3 = obj.LinearRegression()
w3, loss_values = model3.fit(X_3, y3)
np.savetxt('weights3', w3, delimiter=',')


step_numbers = []
for i in range(len(loss_values)):
    step_numbers.append(i+1)

plt.plot(step_numbers, loss_values)
plt.xlabel('Step Number')
plt.ylabel('Loss')
plt.title('Loss vs. Step Number')
plt.grid(True)
plt.show()

# Code to retrive saved weights
# Weights = np.loadtxt("weights3.csv", delimiter=",")
