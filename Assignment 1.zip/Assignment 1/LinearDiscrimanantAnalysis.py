import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split


class LinearDiscriminantAnalysis:

    def __init__(self):
        self.weights = None
        self.bias = None

    def fit(self, X, y, batch_size=32, regularization=0, max_epochs=100, patience=3):

        X = np.array(X)
        y = np.array(y)

        X_arr_0 = X[y == 0]
        # y_arr_0 = y_train[y == 0]
        X_arr_1 = X[y == 1]
        # filtered_labels_1 = y_train[y_train == 1]
        X_arr_2 = X[y == 2]
        # filtered_labels_2 = y_train[y_train == 2]

        pie_0 = len(X_arr_0)/len(y)
        pie_1 = len(X_arr_1)/len(y)
        pie_2 = len(X_arr_2)/len(y)

        myu_0 = 1/len(X_arr_0) * X_arr_0
        myu_0 = np.sum(myu_0, axis=0)
        myu_1 = 1 / len(X_arr_1) * X_arr_1
        myu_1 = np.sum(myu_1, axis=0)
        myu_2 = 1 / len(X_arr_2) * X_arr_2
        myu_2 = np.sum(myu_2, axis=0)
        myu = myu_0 + myu_1 + myu_2

        sigma_0 = 1/len(X_arr_0) * np.dot((X_arr_0 - myu_0).T, (X_arr_0 - myu_0))
        sigma_0 = np.array(sigma_0)
        sigma_1 = 1/len(X_arr_1) * np.dot((X_arr_1 - myu_1).T, (X_arr_1 - myu_1))
        sigma_1 = np.array(sigma_1)
        sigma_2 = 1/len(X_arr_2) * np.dot((X_arr_2 - myu_2).T, (X_arr_2 - myu_2))
        sigma_2 = np.array(sigma_2)
        sigma = sigma_0 + sigma_1 + sigma_2

        weights_0 = np.dot(np.linalg.inv(sigma), myu_0)
        weights_1 = np.dot(np.linalg.inv(sigma), myu_1)
        weights_2 = np.dot(np.linalg.inv(sigma), myu_2)
        self.weights = []
        self.weights.append(weights_0)
        self.weights.append(weights_1)
        self.weights.append(weights_2)
        self.weights = np.array(self.weights)

        bias_0 = -0.5 * np.dot(np.dot(myu_0.T, np.linalg.inv(sigma_0)), myu_0) + np.log(pie_0)
        bias_1 = -0.5 * np.dot(np.dot(myu_1.T, np.linalg.inv(sigma_1)), myu_1) + np.log(pie_1)
        bias_2 = -0.5 * np.dot(np.dot(myu_2.T, np.linalg.inv(sigma_2)), myu_2) + np.log(pie_2)
        self.bias = []
        self.bias.append(bias_0)
        self.bias.append(bias_1)
        self.bias.append(bias_2)
        self.bias = np.array(self.bias)

        return self.weights, self.bias

    def predict(self, X):
        self.nb_class = 3
        pre_vals = np.dot(X, self.weights.T).reshape(-1, self.nb_class) + self.bias
        pre_vals = np.exp(pre_vals) / np.sum(np.exp(pre_vals), axis=1).reshape(-1, 1)
        return np.argmax(pre_vals, axis=1)




