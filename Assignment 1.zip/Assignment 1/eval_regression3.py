import LinearRegression
import train_regression3
import numpy as np


obj = train_regression3
X_test = obj.X_test
y_test = obj.y_test
model3 = obj.model3
X_test = np.array(X_test)
a3 = np.ones((len(X_test), 1), float)
X_test = np.concatenate((a3, X_test), axis=1)
pred3 = model3.predict(X_test)

obj3 = LinearRegression.LinearRegression()
error3 = obj3.score(pred3, y_test)
print(error3)