import numpy as np


class LinearRegression:
    def __init__(self, batch_size=32, regularization=0, max_epochs=100, patience=3):
        """Linear Regression using Gradient Descent.

        Parameters:
        -----------
        batch_size: int
            The number of samples per batch.
        regularization: float
            The regularization parameter.
        max_epochs: int
            The maximum number of epochs.
        patience: int
            The number of epochs to wait before stopping if the validation loss
            does not improve.
        """
        self.batch_size = batch_size
        self.regularization = regularization
        self.max_epochs = max_epochs
        self.patience = patience
        self.weights = None
        self.bias = None

    def fit(self, X, y, batch_size=32, regularization=0.01, max_epochs=100, patience=3):
        """Fit a linear model.

        Parameters:
        -----------
        batch_size: int
            The number of samples per batch.
        regularization: float
            The regularization parameter.
        max_epochs: int
            The maximum number of epochs.
        patience: int
            The number of epochs to wait before stopping if the validation loss
            does not improve.
        """
        self.batch_size = batch_size
        self.regularization = regularization
        self.max_epochs = max_epochs
        self.patience = patience
        learning_rate = 0.001
        X = np.array(X)
        a = np.ones((len(X), 1), float)
        X = np.concatenate((a, X), axis=1)
        y = np.array(y)
        epochs_without_improvements = 0
        best_loss = 999999
        l = []
        # TODO: Initialize the weights and bias based on the shape of X and y.
        self.weights = np.zeros((X.shape[1], 1), float)

        # TODO: Implement the training loop.
        for epochs in range(self.max_epochs):
            for i in range(0, X.shape[0], self.batch_size):
                X_batch = X[i:i+self.batch_size]
                y_batch = y[i:i+self.batch_size]
                y_batch = y_batch.reshape(len(y_batch), 1)
                y_pred = np.dot(X_batch, self.weights)
                gradient_desc = learning_rate * np.dot(X_batch.T, (y_pred - y_batch))
                self.weights = self.weights - gradient_desc
                X_batch_pred = self.predict(X_batch)
                loss_batch = self.score(X_batch_pred, y_batch)
                l.append(loss_batch)

            X_train_pred = self.predict(X)
            loss = self.score(X_train_pred, y)

            if loss < best_loss:
                best_loss = loss
                epochs_without_improvements = 0
            else:
                epochs_without_improvements += 1
                if epochs_without_improvements >= self.patience:
                    print("Early stopping at epoch: "+ str(epochs+1))
                    break
        return self.weights, l

    def predict(self, X):
        """Predict using the linear model.

        Parameters
        ----------
        X: numpy.ndarray
            The input data.
        """
        # TODO: Implement the prediction function.

        return np.dot(X, self.weights)

    def score(self, X, y):
        """Evaluate the linear model using the mean squared error.

        Parameters
        ----------
        X: numpy.ndarray
            The input data.
        y: numpy.ndarray
            The target data.
        """
        # TODO: Implement the scoring function.
        y = y.reshape(len(y), 1)
        return (1/(len(X)*len(y))) * np.sum((X-y)**2)





