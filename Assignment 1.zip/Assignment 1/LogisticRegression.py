import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split


class LogisticRegression:
    def __init__(self, batch_size=32, regularization=0, max_epochs=100, patience=3):

        self.batch_size = batch_size
        self.regularization = regularization
        self.max_epochs = max_epochs
        self.patience = patience
        self.weights = None
        self.bias = None

    def fit(self, X, y, batch_size=32, regularization=0, max_epochs=100, patience=3):
        self.batch_size = batch_size
        self.regularization = regularization
        self.max_epochs = max_epochs
        self.patience = patience
        self.nb_class = 3
        best_loss = 999999
        learning_rate = 0.001
        X = np.array(X)
        y = np.array(y)
        y = y.reshape(y.shape[0], 1)
        y_arr = []
        for y in y:
            if y == 0:
                y_arr.append([1, 0, 0])
            elif y == 1:
                y_arr.append([0, 1, 0])
            else:
                y_arr.append([0, 0, 1])
        y_arr = np.array(y_arr)

        self.weights = np.zeros((self.nb_class, X.shape[1]), float)
        for epochs in range(max_epochs):
            for i in range(0, X.shape[0], self.batch_size):
                X_batch = X[i:i+self.batch_size]
                y_batch = y[i:i+self.batch_size]
                y_batch = y_batch.reshape(y_batch.shape[0], 1)
                y_one_hot = y_arr[i:i+self.batch_size]
                score = np.dot(X_batch, self.weights.T)
                score = np.exp(score) / np.sum(np.exp(score), axis=1).reshape(-1, 1)
                gradient = np.dot((score - y_one_hot).T, X_batch)
                self.weights = self.weights - learning_rate * gradient
            score_after_epoch = np.dot(X, self.weights.T)
            score_after_epoch = np.exp(score_after_epoch) / np.sum(np.exp(score_after_epoch), axis=1).reshape(-1, 1)
            loss = -1 * np.mean(y_arr * np.log(score_after_epoch))
            if loss < best_loss:
                best_loss = loss
                epochs_without_improvements = 0
            else:
                epochs_without_improvements += 1
                if epochs_without_improvements >= self.patience:
                    print("Early stopping at epoch: "+ str(epochs+1))
                    break
        return self.weights

    def predict(self, X):
        X = np.concatenate((np.ones((X.shape[0], 1)), X), axis=-1)
        pre_vals = np.dot(X, self.weights.T).reshape(-1, self.nb_class)
        pre_vals = np.exp(pre_vals) / np.sum(np.exp(pre_vals), axis=1).reshape(-1, 1)
        return np.argmax(pre_vals, axis=1)
