import LinearRegression
import train_regression2
import numpy as np


obj = train_regression2
X_test = obj.X_test
y_test = obj.y_test
model2 = obj.model2
X_test = np.array(X_test)
a2 = np.ones((len(X_test), 1), float)
X_test = np.concatenate((a2, X_test), axis=1)
pred2 = model2.predict(X_test)

obj2 = LinearRegression.LinearRegression()
error2 = obj2.score(pred2, y_test)
print(error2)

