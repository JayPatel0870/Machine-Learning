import LinearRegression
import train_regression4
import numpy as np


obj = train_regression4
X_test = obj.X_test
y_test = obj.y_test
model4 = obj.model4
X_test = np.array(X_test)
a4 = np.ones((len(X_test), 1), float)
X_test = np.concatenate((a4, X_test), axis=1)
pred4 = model4.predict(X_test)

obj4 = LinearRegression.LinearRegression()
error4 = obj4.score(pred4, y_test)
print(error4)
