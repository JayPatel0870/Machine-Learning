import LinearRegression
import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

# Model2 Petal length, Petal Width -->> Sepal Width self.weights = [[ 3.09761038] ,[ 0.06113392], [-0.2068324 ]]
obj = LinearRegression
iris = load_iris()
X = iris['data']
y = iris['target']
X_2 = X[:, [2, 3]]
y2 = X[:, 1]
X_train, X_test, y_train, y_test = train_test_split(X_2, y2, test_size=0.1)
model2 = obj.LinearRegression()
w2, loss_values = model2.fit(X_2, y2)
np.savetxt('weights2', w2, delimiter=',')

step_numbers = []
for i in range(len(loss_values)):
    step_numbers.append(i+1)

plt.plot(step_numbers, loss_values)
plt.xlabel('Step Number')
plt.ylabel('Loss')
plt.title('Loss vs. Step Number')
plt.grid(True)
plt.show()

# Code to retrive saved weights
# Weights = np.loadtxt("weights2.csv", delimiter=",")
