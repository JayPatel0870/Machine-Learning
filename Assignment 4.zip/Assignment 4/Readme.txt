Citation 

Model Name: GPT-3.5 (ChatGPT)
Developed by: OpenAI
Release Date: June 2020
Version: 3.5