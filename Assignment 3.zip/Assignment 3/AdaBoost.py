import numpy as np
import pandas as pd
import re
# import DecisionTree
from sklearn.tree import DecisionTreeClassifier


class AdaBoost:
    def __init__(self, weak_learner, num_learners, learning_rate):
        self.weak_learner = weak_learner
        self.num_learners = num_learners
        self.learning_rate = learning_rate
        self.learners = []
        self.alphas = []

    def fit(self, X, y):
        n_samples = X.shape[0]
        sample_weights = np.ones(n_samples) / n_samples

        for _ in range(self.num_learners):
            learner = self.weak_learner()
            learner.fit(X, y, sample_weights)

            y_pred = learner.predict(X)
            error = np.sum(sample_weights * (y_pred != y))

            if error > 0.5:
                break

            alpha = 0.5 * np.log((1.0 - error) / (error + 1e-10))
            self.alphas.append(alpha)
            self.learners.append(learner)

            sample_weights = sample_weights * np.exp(-alpha * y * y_pred)
            sample_weights = sample_weights / np.sum(sample_weights)
            # sample_weights = np.array(sample_weights)
            # sample_weights = sample_weights.reshape(sample_weights.shape[0], 1)

    def predict(self, X):
        learner_preds = [learner.predict(X) for learner in self.learners]
        weighted_preds = np.array([alpha * pred for alpha, pred in zip(self.alphas, learner_preds)])
        y_pred = np.sign(np.sum(weighted_preds, axis=0))
        return y_pred


train = pd.read_csv('Titanic/train.csv')
test = pd.read_csv('Titanic/test.csv')


PassengerId = test['PassengerId']

original_train = train.copy()
full_data = [train, test]

train['Has_Cabin'] = train["Cabin"].apply(lambda x: 0 if type(x) == float else 1)
test['Has_Cabin'] = test["Cabin"].apply(lambda x: 0 if type(x) == float else 1)

for dataset in full_data:
    dataset['FamilySize'] = dataset['SibSp'] + dataset['Parch'] + 1

for dataset in full_data:
    dataset['IsAlone'] = 0
    dataset.loc[dataset['FamilySize'] == 1, 'IsAlone'] = 1

for dataset in full_data:
    dataset['Embarked'] = dataset['Embarked'].fillna('S')

for dataset in full_data:
    dataset['Fare'] = dataset['Fare'].fillna(train['Fare'].median())

for dataset in full_data:
    age_avg = dataset['Age'].mean()
    age_std = dataset['Age'].std()
    age_null_count = dataset['Age'].isnull().sum()
    age_null_random_list = np.random.randint(age_avg - age_std, age_avg + age_std, size=age_null_count)
    # Next line has been improved to avoid warning
    dataset.loc[np.isnan(dataset['Age']), 'Age'] = age_null_random_list
    dataset['Age'] = dataset['Age'].astype(int)


def get_title(name):
    title_search = re.search(' ([A-Za-z]+)\.', name)
    # If the title exists, extract and return it.
    if title_search:
        return title_search.group(1)
    return ""


for dataset in full_data:
    dataset['Title'] = dataset['Name'].apply(get_title)
# Group all non-common titles into one single grouping "Rare"
for dataset in full_data:
    dataset['Title'] = dataset['Title'].replace(['Lady', 'Countess', 'Capt', 'Col', 'Don', 'Dr', 'Major', 'Rev', 'Sir', 'Jonkheer', 'Dona'], 'Rare')
    dataset['Title'] = dataset['Title'].replace('Mlle', 'Miss')
    dataset['Title'] = dataset['Title'].replace('Ms', 'Miss')
    dataset['Title'] = dataset['Title'].replace('Mme', 'Mrs')

for dataset in full_data:
    # Mapping Sex
    dataset['Sex'] = dataset['Sex'].map( {'female': 0, 'male': 1} ).astype(int)
    title_mapping = {"Mr": 1, "Master": 2, "Mrs": 3, "Miss": 4, "Rare": 5}
    dataset['Title'] = dataset['Title'].map(title_mapping)
    dataset['Title'] = dataset['Title'].fillna(0)
    dataset['Embarked'] = dataset['Embarked'].map({'S': 0, 'C': 1, 'Q': 2}).astype(int)
    dataset.loc[dataset['Fare'] <= 7.91, 'Fare'] = 0
    dataset.loc[(dataset['Fare'] > 7.91) & (dataset['Fare'] <= 14.454), 'Fare'] = 1
    dataset.loc[(dataset['Fare'] > 14.454) & (dataset['Fare'] <= 31), 'Fare'] = 2
    dataset.loc[dataset['Fare'] > 31, 'Fare'] = 3
    dataset['Fare'] = dataset['Fare'].astype(int)
    dataset.loc[dataset['Age'] <= 16, 'Age'] = 0
    dataset.loc[(dataset['Age'] > 16) & (dataset['Age'] <= 32), 'Age'] = 1
    dataset.loc[(dataset['Age'] > 32) & (dataset['Age'] <= 48), 'Age'] = 2
    dataset.loc[(dataset['Age'] > 48) & (dataset['Age'] <= 64), 'Age'] = 3
    dataset.loc[dataset['Age'] > 64, 'Age'];


drop_elements = ['PassengerId', 'Name', 'Ticket', 'Cabin', 'SibSp']
train = train.drop(drop_elements, axis=1)
test = test.drop(drop_elements, axis=1)


y_train = train['Survived']
x_train = train.drop(['Survived'], axis=1).values
x_test = test.values


adaboost_model = AdaBoost(weak_learner=DecisionTreeClassifier, num_learners=50, learning_rate=0.1)
adaboost_model.fit(x_train, y_train)
y_pred = adaboost_model.predict(x_test)

y_test = pd.read_csv('Titanic/gender_submission.csv')
y_test = y_test['Survived']
y_test = np.array(y_test)

count = 0
for i in range(y_test.shape[0]):
    if y_test[i] == y_pred[i]:
        count += 1
    else:
        count += 0

count = count/y_test.shape[0]
print("Decision Tree Accuracy: " + str(count))
