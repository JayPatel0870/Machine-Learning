import numpy as np
import pandas as pd
import re


class DecisionTree:
    def __init__(self, criterion = 'gini', max_depth=None, min_samples_split=2, min_samples_leaf=1):
        self.criterion = criterion
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.min_samples_leaf = min_samples_leaf
        self.tree = None

    def gini(self, y):
        _, counts = np.unique(y, return_counts=True)
        probabilities = counts / len(y)
        gini = 1 - np.sum(probabilities ** 2)
        return gini

    def split(self, X, y, feature_index, threshold):
        left_mask = X[:, feature_index] <= threshold
        right_mask = ~left_mask
        return y[left_mask], y[right_mask]

    def find_best_split(self, X, y, sample_weights):
        best_gini = float('inf')
        best_split = None

        for feature_index in range(X.shape[1]):
            unique_values = np.unique(X[:, feature_index])
            for threshold in unique_values:
                y_left, y_right = self.split(X, y, feature_index, threshold)
                weights_left, weights_right = sample_weights[y_left], sample_weights[y_right]

                gini_left = self.gini(y_left)
                gini_right = self.gini(y_right)

                weighted_gini = (np.sum(weights_left) / np.sum(sample_weights)) * gini_left + \
                                (np.sum(weights_right) / np.sum(sample_weights)) * gini_right

                if weighted_gini < best_gini:
                    best_gini = weighted_gini
                    best_split = (feature_index, threshold)

        return best_split

    def build_tree(self, X, y, sample_weights, depth):
        if depth == self.max_depth or len(np.unique(y)) == 1 or len(y) < self.min_samples_split:
            return np.bincount(y, weights=sample_weights).argmax()

        best_split = self.find_best_split(X, y, sample_weights)
        if best_split is None:
            return np.bincount(y, weights=sample_weights).argmax()

        feature_index, threshold = best_split
        y_left, y_right = self.split(X, y, feature_index, threshold)
        weights_left, weights_right = sample_weights[y_left], sample_weights[y_right]

        left_subtree = self.build_tree(X[y_left], y_left, weights_left, depth + 1)
        right_subtree = self.build_tree(X[y_right], y_right, weights_right, depth + 1)

        return (feature_index, threshold, left_subtree, right_subtree)

    def fit(self, X, y, sample_weights=None):
        if sample_weights is None:
            sample_weights = np.ones(len(y)) / len(y)
        else:
            sample_weights = sample_weights / np.sum(sample_weights)  # Normalize the weights

        self.tree = self.build_tree(X, y, sample_weights, depth=1)

    def predict(self, X):
        def predict_sample(x, node):
            if isinstance(node, np.int64):
                return node
            feature_index, threshold, left_subtree, right_subtree = node
            if x[feature_index] <= threshold:
                return predict_sample(x, left_subtree)
            else:
                return predict_sample(x, right_subtree)

        y_pred = np.array([predict_sample(x, self.tree) for x in X])
        return y_pred


train = pd.read_csv('Titanic/train.csv')
test = pd.read_csv('Titanic/test.csv')


PassengerId = test['PassengerId']

original_train = train.copy()
full_data = [train, test]

train['Has_Cabin'] = train["Cabin"].apply(lambda x: 0 if type(x) == float else 1)
test['Has_Cabin'] = test["Cabin"].apply(lambda x: 0 if type(x) == float else 1)

for dataset in full_data:
    dataset['FamilySize'] = dataset['SibSp'] + dataset['Parch'] + 1

for dataset in full_data:
    dataset['IsAlone'] = 0
    dataset.loc[dataset['FamilySize'] == 1, 'IsAlone'] = 1

for dataset in full_data:
    dataset['Embarked'] = dataset['Embarked'].fillna('S')

for dataset in full_data:
    dataset['Fare'] = dataset['Fare'].fillna(train['Fare'].median())

for dataset in full_data:
    age_avg = dataset['Age'].mean()
    age_std = dataset['Age'].std()
    age_null_count = dataset['Age'].isnull().sum()
    age_null_random_list = np.random.randint(age_avg - age_std, age_avg + age_std, size=age_null_count)
    # Next line has been improved to avoid warning
    dataset.loc[np.isnan(dataset['Age']), 'Age'] = age_null_random_list
    dataset['Age'] = dataset['Age'].astype(int)


def get_title(name):
    title_search = re.search(' ([A-Za-z]+)\.', name)
    # If the title exists, extract and return it.
    if title_search:
        return title_search.group(1)
    return ""


for dataset in full_data:
    dataset['Title'] = dataset['Name'].apply(get_title)
# Group all non-common titles into one single grouping "Rare"
for dataset in full_data:
    dataset['Title'] = dataset['Title'].replace(['Lady', 'Countess', 'Capt', 'Col', 'Don', 'Dr', 'Major', 'Rev', 'Sir', 'Jonkheer', 'Dona'], 'Rare')
    dataset['Title'] = dataset['Title'].replace('Mlle', 'Miss')
    dataset['Title'] = dataset['Title'].replace('Ms', 'Miss')
    dataset['Title'] = dataset['Title'].replace('Mme', 'Mrs')

for dataset in full_data:
    # Mapping Sex
    dataset['Sex'] = dataset['Sex'].map( {'female': 0, 'male': 1} ).astype(int)
    title_mapping = {"Mr": 1, "Master": 2, "Mrs": 3, "Miss": 4, "Rare": 5}
    dataset['Title'] = dataset['Title'].map(title_mapping)
    dataset['Title'] = dataset['Title'].fillna(0)
    dataset['Embarked'] = dataset['Embarked'].map({'S': 0, 'C': 1, 'Q': 2}).astype(int)
    dataset.loc[dataset['Fare'] <= 7.91, 'Fare'] = 0
    dataset.loc[(dataset['Fare'] > 7.91) & (dataset['Fare'] <= 14.454), 'Fare'] = 1
    dataset.loc[(dataset['Fare'] > 14.454) & (dataset['Fare'] <= 31), 'Fare'] = 2
    dataset.loc[dataset['Fare'] > 31, 'Fare'] = 3
    dataset['Fare'] = dataset['Fare'].astype(int)
    dataset.loc[dataset['Age'] <= 16, 'Age'] = 0
    dataset.loc[(dataset['Age'] > 16) & (dataset['Age'] <= 32), 'Age'] = 1
    dataset.loc[(dataset['Age'] > 32) & (dataset['Age'] <= 48), 'Age'] = 2
    dataset.loc[(dataset['Age'] > 48) & (dataset['Age'] <= 64), 'Age'] = 3
    dataset.loc[dataset['Age'] > 64, 'Age'];


drop_elements = ['PassengerId', 'Name', 'Ticket', 'Cabin', 'SibSp']
train = train.drop(drop_elements, axis=1)
test = test.drop(drop_elements, axis=1)


y_train = train['Survived']
x_train = train.drop(['Survived'], axis=1).values
x_test = test.values
decision_tree = DecisionTree(max_depth=3, min_samples_split=2)
decision_tree.fit(x_train, y_train)
y_pred = decision_tree.predict(x_test)

y_test = pd.read_csv('Titanic/gender_submission.csv')
y_test = y_test['Survived']
y_test = np.array(y_test)

count = 0
for i in range(y_test.shape[0]):
    if y_test[i] == y_pred[i]:
        count += 1
    else:
        count += 0

count = count/y_test.shape[0]
print("Decision Tree Accuracy: " + str(count))
