import numpy as np
import Layer as nn
import matplotlib.pyplot as plt

input_dim = 2
hidden_dim = 2
output_dim = 1

X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])

y = np.array([[0], [1], [1], [0]])


model = nn.Sequential([
    nn.Linear(input_dim, hidden_dim),
    nn.HyperbolicTangent(),
    nn.Linear(hidden_dim, output_dim),
    nn.HyperbolicTangent()
])

number_epochs = 200
learning_rate = 0.3
best_loss = 99999
Early_Stopping = 5
count = 0
best_loss = 99999
l = []


for epoch in range(number_epochs):

    # Forward Pass
    output = model.forward(X)
    squared_error = np.square(output - y)
    mse = np.mean(squared_error)
    l.append(mse)

    # Calculating Loss
    loss = nn.CrossEntropyLoss().forward(output, y)

    # Backward Pass
    grad = nn.CrossEntropyLoss().backward(output, y)
    model.backward(grad)

    for layer in model.layers:
        if isinstance(layer, nn.Linear):
            layer.weights = layer.weights - (learning_rate * layer.grad_weights)
            layer.bias = layer.bias - (learning_rate * layer.grad_bias)
            w = layer.weights
            b = layer.bias
    # print(f"Epoch {epoch+1}/{number_epochs}, Loss: {loss}")

    validation_loss = mse
    if validation_loss < best_loss:
        best_loss = validation_loss
        count = 0
    else:
        count += 1
        if count >= Early_Stopping:
            print("Early stopping at epoch: " + str(epoch + 1))
            break
    # print("EPOCH:" + str(epoch + 1) + " Completed Successfully")


# X_train_predict = model.forward(X)
# print(X_train_predict)
#
# X_train_predict = X_train_predict.reshape(len(X_train_predict), )
# X_training_predicts = []
# for i in X_train_predict:
#     if i >= 0.5:
#         X_training_predicts.append(1)
#     else:
#         X_training_predicts.append(0)
#
# X_training_predicts = np.array(X_training_predicts)
# print(X_training_predicts)
# y = y.reshape(len(y), )
# print(y)
# c = 0
# for i in range(len(y)):
#     if y[i] == X_training_predicts[i]:
#         c += 1
#     else:
#         c += 0
# print(str((c/4)*100)+" %")


X_test = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
predicts = model.forward(X_test)
p = []
for i in predicts:
    if i >= 0.5:
        p.append(1)
    else:
        p.append(0)
predicts = np.array(p)

# print(predicts)
c = 0
for i in range(len(y)):
    if y[i] == predicts[i]:
        c += 1
    else:
        c += 0

print("Model1")
print("Test Accuracy: "+str((c/4)*100)+" %")

np.savetxt("Weights1XOR", w, delimiter=',')
np.savetxt("Bias1XOR", b, delimiter=',')

step_numbers = []
for i in range(len(l)):
    step_numbers.append(i+1)

plt.plot(step_numbers, l)
plt.xlabel('Step Number')
plt.ylabel('Loss')
plt.title('Loss vs. Step Number')
plt.grid(True)
plt.show()
