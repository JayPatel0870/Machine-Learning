import numpy as np
from keras.datasets import mnist
import Layer as nn
from sklearn.preprocessing import OneHotEncoder
import matplotlib.pyplot as plt


input_dimension = 784
hidden_dimension = 100
output_dimension = 10
learning_rate = 0.001
Batch_size = 128
number_epochs = 10
Early_Stopping = 5
count = 0
best_loss = 99999
encoder = OneHotEncoder(sparse=False)
l = []

print("Model3")
print("784 -> 100 -> 10")
print("Activation function : Hyperbolic Tangent")
print("Learning rate:0.001")
print("Max Epochs: 10")
print("Early Stopping: 5")


model = nn.Sequential([
    nn.Linear(input_dimension, hidden_dimension),
    nn.HyperbolicTangent(),
    nn.Linear(hidden_dimension, output_dimension),
    nn.HyperbolicTangent()
])

(X_train, y_train), (X_test, y_test) = mnist.load_data()
X_train = X_train.reshape(-1, 28*28)
y_train = y_train.reshape(-1, 1)
y_train_one_hot = encoder.fit_transform(y_train.reshape(-1, 1))
X_test = X_test.reshape(-1, 28*28)
y_test = y_test.reshape(-1, 1)


for epoch in range(number_epochs):
    for i in range(0, len(X_train), Batch_size):
        X_train_batch = X_train[i:i+Batch_size]
        y_train_batch = y_train[i:i+Batch_size]
        y_train_batch_one_hot = y_train_one_hot[i:i+Batch_size]

        output = model.forward(X_train_batch)
        squared_error = np.square(output - y_train_batch)
        mse = np.mean(squared_error)
        l.append(mse)
        loss = nn.CrossEntropyLoss().backward(output, y_train_batch_one_hot)

        grad = nn.CrossEntropyLoss().backward(output, y_train_batch_one_hot)
        model.backward(grad)

        for layer in model.layers:
            if isinstance(layer, nn.Linear):
                layer.weights = layer.weights - (learning_rate * layer.grad_weights)
                layer.bias = layer.bias - (learning_rate * layer.grad_bias)
                w = layer.weights
                b = layer.bias
        # print(f"Epoch {epoch + 1}/{number_epochs}, Loss: {loss}")
    # print("EPOCH:"+str(epoch+1)+" Completed Successfully")

    sum_loss = mse
    if sum_loss < best_loss:
        best_loss = sum_loss
        count = 0
    else:
        count += 1
        if count >= Early_Stopping:
            print("Early stopping at epoch: " + str(epoch + 1))
            break

    # print("EPOCH:" + str(epoch + 1) + " Completed Successfully")

# train_accuracy = model.forward(X_train)
# train_accuracy = np.argmax(train_accuracy, axis=1)
# y_train = y_train.reshape(len(y_train), )
# count1 = 0
# for i in range(len(train_accuracy)):
#     if train_accuracy[i] == y_train[i]:
#         count1 += 1
#     else:
#         count1 += 0
#
# print(str(count1/600) + "%")

predict = model.forward(X_test)
predict = np.argmax(predict, axis=1)
y_test = y_test.reshape(len(y_test), )
# print(predict)
# print(y_test)


count = 0
for i in range(len(predict)):
    if predict[i] == y_test[i]:
        count += 1
    else:
        count += 0

count = count/100
print("Model3")
print("Test Accuracy: "+str(count)+"%")

np.savetxt("Weights3MNIST", w, delimiter=',')
np.savetxt("Bias3MNIST", b, delimiter=',')

step_numbers = []
for i in range(len(l)):
    step_numbers.append(i+1)

plt.plot(step_numbers, l)
plt.xlabel('Step Number')
plt.ylabel('Loss')
plt.title('Loss vs. Step Number')
plt.grid(True)
plt.show()

