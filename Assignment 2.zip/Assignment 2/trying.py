import numpy as np

# def HyperBolicTangent(x, grad):
#     return (np.exp(x) - np.exp(-x)) / (np.exp(x) + np.exp(-x)) * grad
#
#
# i = np.array([0,0.01,0.002])
# y = HyperBolicTangent(i, 0.221)
# print(y)