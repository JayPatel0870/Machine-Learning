import numpy as np


class Layer:

    def forward(self):
        pass

    def backward(self):
        pass


class Linear(Layer):

    def __init__(self, input_dim, output_dim):
        self.weights = np.random.randn(output_dim, input_dim)
        self.bias = np.random.randn(1, output_dim)

    def forward(self, X):
        self.X = X
        return np.dot(X, self.weights.T) + self.bias

    def backward(self, grad):
        self.grad_weights = np.dot(grad.T, self.X)
        self.grad_bias = np.sum(grad, axis=0)
        return np.dot(grad, self.weights)


class Sigmoid(Layer):
    def forward(self, x):
        self.out = 1 / (1 + np.exp(-x))
        return self.out

    def backward(self, grad):
        return grad * self.out * (1 - self.out)


class HyperbolicTangent(Layer):
    def forward(self, x):
        self.out = np.tanh(x) #(np.exp(x) - np.exp(-x)) / (np.exp(x) + np.exp(-x))
        return self.out

    def backward(self, grad):
        return grad * (1 - (self.out ** 2))


class Softmax(Layer):
    def forward(self, fx):
        fx = self.sigmoid(fx)
        exp_sum = np.sum(fx, axis=0, dtype=float)
        fx = fx / exp_sum
        return fx

    def backward(self, grad):
        return grad

    def sigmoid(self, z):
        return 1 / (1+np.exp(-z))


class CrossEntropyLoss(Layer):
    def forward(self, X, y):
        # Cross Entropy
        X = self.softmax(X)
        return -1 * y * np.log(X)
        # Binary Cross Entropy
        # loss = y * np.log(X) + (1 - y) * np.log(1-X)
        # return loss

    def backward(self, y_pred, y):
        return y_pred - y

    def softmax(self, fx):
        exp_sum = np.sum(fx, axis=0, dtype=float)
        fx = fx / exp_sum
        return fx


class Sequential(Layer):
    def __init__(self, layers):
        self.layers = layers

    def forward(self, X):
        for layer in self.layers:
            X = layer.forward(X)
        return X

    def backward(self, grad):
        for layer in reversed(self.layers):
            grad = layer.backward(grad)
        return grad


